Implementasi paling dasar dan sangat sederhana untuk menghitung peluang untuk salah satu bidang ketika sampel dilakukan tanpa pengembalian.

<!--- Implikasi
Dengan opsi konvensional, integers memiliki batas nilai sebesar 2147483647 atau 2 pangkat 31. Kapasitas yang dibutuhkan lebih besar, sehingga jika ingin memasukkan nilai lebih dari yang diterangkan atau 10, sehingga mungkin perlulah untuk memilih tipe data lain. Dalam hal ini ada " long long " atau "Big Integers", namun materi header atau headline tidak selalu tersedia langsung atau secara otomatis, sehingga memakai tipe data itu dengan batasan yang ada sebagai kunci utama. -->


<h3>Keterangan</h3>
Ini merupakan hasil pengerjaan tugas kelompok 7 UTP pertama mata kuliah dasar-dasar pemrograman semester 1.
